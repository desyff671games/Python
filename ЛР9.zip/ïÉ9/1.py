import requests

# Функция для получения списка всех студентов
def get_students_list():
    url = "http://127.0.0.1:80/students"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print("Ошибка при получении списка студентов:", response.status_code)
        return None

# Функция для получения информации о конкретном студенте по его номеру
def get_student_info(student_id):
    url = f"http://127.0.0.1:80/students/{student_id}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        print("Студент с таким номером не найден")
        return None
    else:
        print("Ошибка при получении информации о студенте:", response.status_code)
        return None

# Пример использования функций
print("Список студентов:")
students_list = get_students_list()
if students_list:
    print(students_list)

print("\nИнформация о студенте с номером 1:")
student_info = get_student_info(1)
if student_info:
    print(student_info)


import requests

# Функция для добавления нового студента на сервер
def add_student(student_data):
    url = "http://127.0.0.1:80/students"
    response = requests.post(url, json=student_data)
    return response.json()

# Пример использования функции
new_student_data = {"id": 4, "name": "Новый Студент", "age": 22, "major": "Биология"}
response = add_student(new_student_data)
print(response)


import requests

def update_student_info(student_id, updated_student_data):
    url = f"http://127.0.0.1:80/students/{student_id}"
    response = requests.put(url, json=updated_student_data)
    return response.json()

# Пример использования функции
student_id = 4
updated_data = {"name": "Новый Студент", "age": 23, "major": "Химия"}
response = update_student_info(student_id, updated_data)
print(response)



import requests

def delete_student(student_id):
    url = f"http://127.0.0.1:80/students/{student_id}"
    response = requests.delete(url)
    return response.json()

# Пример использования функции
student_id = 4
response = delete_student(student_id)
print(response)
