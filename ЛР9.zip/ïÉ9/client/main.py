import requests

# URL сервера
SERVER_URL = "http://127.0.0.1"

# Получение списка всех студентов
def get_students():
    response = requests.get(f"{SERVER_URL}/students")
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Получение данных конкретного студента по его идентификатору
def get_student(student_id):
    response = requests.get(f"{SERVER_URL}/students/{student_id}")
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Добавление нового студента
def add_student(student_data):
    response = requests.post(f"{SERVER_URL}/students", json=student_data)
    if response.status_code == 201:
        return response.json()
    else:
        return None

# Обновление данных студента по его идентификатору
def update_student(student_id, student_data):
    response = requests.put(f"{SERVER_URL}/students/{student_id}", json=student_data)
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Удаление студента по его идентификатору
def delete_student(student_id):
    response = requests.delete(f"{SERVER_URL}/students/{student_id}")
    if response.status_code == 200:
        return True
    else:
        return False

# Пример использования функций
if __name__ == "__main__":
    # Получение списка всех студентов
    all_students = get_students()
    print("Список всех студентов:")
    print(all_students)
    print()

    # Получение данных конкретного студента по его идентификатору
    student_id = 2
    student_info = get_student(student_id)
    if student_info:
        print(f"Данные студента с ID {student_id}:")
        print(student_info)
    else:
        print(f"Студент с ID {student_id} не найден")
    print()

    # Добавление нового студента
    new_student_data = {"id": 4, "name": "Новый Студент", "age": 22, "major": "Информатика"}
    new_student = add_student(new_student_data)
    if new_student:
        print("Новый студент успешно добавлен:")
        print(new_student)
    else:
        print("Ошибка при добавлении нового студента")
    print()

    # Обновление данных студента
    updated_student_data = {"name": "Иванов Иван Иванович", "age": 23}
    updated_student = update_student(1, updated_student_data)
    if updated_student:
        print("Данные студента успешно обновлены:")
        print(updated_student)
    else:
        print("Ошибка при обновлении данных студента")
    print()

    # Удаление студента
    deleted = delete_student(3)
    if deleted:
        print("Студент успешно удален")
    else:
        print("Ошибка при удалении студента")
